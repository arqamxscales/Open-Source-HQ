import SwiftUI
import CoreHaptics

// 1. DATA MODEL
struct LogEntry: Identifiable {
    let id = UUID()
    let message: String
    let isAlert: Bool
}

struct ContentView: View {
    // 2. STATE VARIABLES
    @State private var logs: [LogEntry] = [
        LogEntry(message: "SYSTEM: PrivacyLens initialized. Monitoring data flow...", isAlert: false)
    ]
    @State private var isLocationEnabled = false
    @State private var isTrackingEnabled = false
    
    // 3. THE USER INTERFACE
    var body: some View {
        GeometryReader { geo in
            HStack(spacing: 0) {
                // LEFT SIDE: THE "TRAP" APP UI
                VStack(spacing: 20) {
                    HeaderView()
                    
                    ScrollView {
                        VStack(spacing: 15) {
                            AppFeatureCard(title: "Smart Weather",
                                           icon: "cloud.sun.fill",
                                           description: "Get local updates.",
                                           toggle: $isLocationEnabled)
                                .onChange(of: isLocationEnabled) { newValue in
                                    handleLocationToggle(enabled: newValue)
                                }
                            
                            AppFeatureCard(title: "Ad Personalization",
                                           icon: "target",
                                           description: "See relevant content.",
                                           toggle: $isTrackingEnabled)
                                .onChange(of: isTrackingEnabled) { newValue in
                                    handleTrackingToggle(enabled: newValue)
                                }
                            
                            Button(action: simulatePhotoUpload) {
                                Text("Upload Recent Photo")
                                    .fontWeight(.bold)
                                    .padding()
                                    .frame(maxWidth: .infinity)
                                    .background(Color.blue)
                                    .foregroundColor(.white)
                                    .cornerRadius(12)
                            }
                        }
                        .padding()
                    }
                }
                .frame(width: geo.size.width * 0.5)
                .background(Color(.systemGroupedBackground))
                
                // RIGHT SIDE: THE PRIVACY LOG (CONSOLE)
                ZStack {
                    Color.black.edgesIgnoringSafeArea(.all)
                    
                    VStack(alignment: .leading) {
                        Text("DEVELOPER CONSOLE (HIDDEN)")
                            .font(.system(size: 12, weight: .bold, design: .monospaced))
                            .foregroundColor(.green)
                            .padding()
                        
                        ScrollViewReader { proxy in
                            ScrollView {
                                VStack(alignment: .leading, spacing: 10) {
                                    ForEach(logs) { log in
                                        Text(log.message)
                                            .font(.system(size: 11, design: .monospaced))
                                            .foregroundColor(log.isAlert ? .red : .green)
                                            .padding(.horizontal)
                                            .id(log.id)
                                    }
                                }
                            }
                            .onChange(of: logs.count) { _ in
                                withAnimation { proxy.scrollTo(logs.last?.id) }
                            }
                        }
                    }
                }
                .frame(width: geo.size.width * 0.5)
            }
        }
    }
    
    // 4. LOGIC FUNCTIONS
    func addLog(_ msg: String, isAlert: Bool = false) {
        let formatter = DateFormatter()
        formatter.dateFormat = "HH:mm:ss"
        let timestamp = formatter.string(from: Date())
        
        logs.append(LogEntry(message: "[\(timestamp)] \(msg)", isAlert: isAlert))
        
        if isAlert {
            let generator = UINotificationFeedbackGenerator()
            generator.notificationOccurred(.error)
        }
    }
    
    func handleLocationToggle(enabled: Bool) {
        if enabled {
            addLog("⚠️ ACCESS GRANTED: Fetching GPS...")
            addLog("⚠️ EXFILTRATING: Lat 37.33, Long -122.01", isAlert: true)
        } else {
            addLog("✅ ACCESS REVOKED: Location services cut.")
        }
    }
    
    func handleTrackingToggle(enabled: Bool) {
        if enabled {
            addLog("⚠️ IDFA BROADCAST: Tracking ID sent to 3rd parties.", isAlert: true)
        } else {
            addLog("🛡️ ATT BLOCK: Tracking identifier set to 0s.")
        }
    }
    
    func simulatePhotoUpload() {
        addLog("🛰️ UPLOAD STARTED: IMG_4402.PNG")
        addLog("⚠️ EXIF SCAN: Found Location: Apple Park, CA", isAlert: true)
        addLog("⚠️ DATA: Device serial and lens metadata extracted.", isAlert: true)
    }
}

// 5. SUPPORTING VIEWS
struct HeaderView: View {
    var body: some View {
        VStack {
            Image(systemName: "eye.trianglebadge.exclamationmark")
                .font(.system(size: 50))
                .foregroundColor(.blue)
            Text("PrivacyLens").font(.title2).bold()
        }
        .padding(.top)
    }
}

struct AppFeatureCard: View {
    let title: String
    let icon: String
    let description: String
    @Binding var toggle: Bool
    
    var body: some View {
        VStack(alignment: .leading) {
            HStack {
                Image(systemName: icon).foregroundColor(.blue)
                Text(title).bold()
                Spacer()
                Toggle("", isOn: $toggle).labelsHidden()
            }
            Text(description).font(.caption).foregroundColor(.secondary)
        }
        .padding()
        .background(Color.white)
        .cornerRadius(12)
    }
}
