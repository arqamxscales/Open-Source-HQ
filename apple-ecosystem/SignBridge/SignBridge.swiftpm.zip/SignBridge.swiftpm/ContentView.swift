import SwiftUI

struct ContentView: View {
    @StateObject var camera = CameraManager()
    
    var body: some View {
        ZStack {
            // Background Layer
            CameraPreview(session: camera.session)
                .ignoresSafeArea()
            
            // Phase 3: Canvas Skeleton Overlay
            Canvas { context, size in
                for (_, point) in camera.handPoints {
                    let x = point.x * size.width
                    let y = (1 - point.y) * size.height
                    context.fill(Path(ellipseIn: CGRect(x: x, y: y, width: 6, height: 6)), with: .color(.cyan))
                }
            }
            .opacity(0.8)
            
            // Phase 4: Accessible UI Elements
            VStack {
                Text("SignBridge")
                    .font(.largeTitle.bold())
                    .foregroundStyle(.white)
                    .padding()
                    .background(RoundedRectangle(cornerRadius: 15).fill(.black.opacity(0.4)))
                
                Text(camera.currentMessage)
                    .font(.headline)
                    .foregroundStyle(.white)
                    .padding()
                    .background(.ultraThinMaterial)
                    .clipShape(Capsule())
                    .padding(.top, 10)
                
                Spacer()
                
                // Phase 3: Celebration Animation
                if camera.isSuccess {
                    VStack {
                        if #available(macCatalyst 17.0, *) {
                            Image(systemName: "hand.thumbsup.fill")
                                .font(.system(size: 80))
                                .foregroundStyle(.yellow)
                                .phaseAnimator([false, true]) { content, phase in
                                    content
                                        .scaleEffect(phase ? 1.4 : 1.0)
                                        .rotationEffect(.degrees(phase ? 10 : -10))
                                } animation: { _ in .spring(duration: 0.4) }
                        } else {
                            // Fallback on earlier versions
                        }
                        
                        Text(camera.detectedSign)
                            .font(.title.bold())
                            .foregroundStyle(.white)
                    }
                    .transition(.scale.combined(with: .opacity))
                }
            }
            .padding(.bottom, 50)
        }
    }
}
