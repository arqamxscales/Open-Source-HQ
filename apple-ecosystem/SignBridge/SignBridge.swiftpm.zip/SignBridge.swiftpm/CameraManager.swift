@preconcurrency import AVFoundation
import Vision
import SwiftUI
import CoreHaptics

@MainActor
class CameraManager: NSObject, ObservableObject, AVCaptureVideoDataOutputSampleBufferDelegate {
    @Published var handPoints: [VNHumanHandPoseObservation.JointName: CGPoint] = [:]
    @Published var isSuccess: Bool = false
    @Published var currentMessage: String = "Show your hand to start"
    @Published var detectedSign: String = ""
    
    private var isThankYouStarted = false
    let session = AVCaptureSession()
    private let output = AVCaptureVideoDataOutput()
    private let queue = DispatchQueue(label: "camera.queue")
    
    override init() {
        super.init()
        setupSession()
    }
    
    private func setupSession() {
        guard let device = AVCaptureDevice.default(.builtInWideAngleCamera, for: .video, position: .front),
              let input = try? AVCaptureDeviceInput(device: device) else { return }
        
        session.beginConfiguration()
        if session.canAddInput(input) { session.addInput(input) }
        output.setSampleBufferDelegate(self, queue: queue)
        if session.canAddOutput(output) { session.addOutput(output) }
        session.commitConfiguration()
        
        // FIX: Using a captured reference in a background thread to avoid 'Non-Sendable' Task errors
        let cameraSession = self.session
        DispatchQueue.global(qos: .userInitiated).async {
            cameraSession.startRunning()
        }
    }
    
    // 'nonisolated' allows the camera queue to call this without blocking the MainActor
    nonisolated func captureOutput(_ output: AVCaptureOutput, didOutput sampleBuffer: CMSampleBuffer, from connection: AVCaptureConnection) {
        let handler = VNImageRequestHandler(cmSampleBuffer: sampleBuffer, orientation: .up, options: [:])
        let request = VNDetectHumanHandPoseRequest()
        
        do {
            try handler.perform([request])
            guard let observation = request.results?.first else { return }
            
            // We jump back to the MainActor safely to update UI variables
            Task { @MainActor in
                self.processHand(observation)
            }
        } catch {
            return
        }
    }
    
    private func processHand(_ observation: VNHumanHandPoseObservation) {
        guard observation.confidence > 0.9 else { return }
        do {
            let joints = try observation.recognizedPoints(.all)
            var detectedPoints: [VNHumanHandPoseObservation.JointName: CGPoint] = [:]
            for (joint, point) in joints where point.confidence > 0.7 {
                detectedPoints[joint] = point.location
            }
            self.handPoints = detectedPoints
            self.checkHelloSign(observation)
        } catch {
            return
        }
    }
    
    private func checkHelloSign(_ observation: VNHumanHandPoseObservation) {
        guard !isSuccess else { return }
        do {
            let wrist = try observation.recognizedPoint(.wrist)
            let indexTip = try observation.recognizedPoint(.indexTip)
            
            if indexTip.location.y > wrist.location.y + 0.3 {
                triggerSuccess(name: "Hello")
            }
        } catch {
            return
        }
    }
    
    private func triggerSuccess(name: String) {
        isSuccess = true
        detectedSign = name
        currentMessage = "Perfect: \(name)!"
        
        // Native Haptics and Accessibility
        UIImpactFeedbackGenerator(style: .heavy).impactOccurred()
        UIAccessibility.post(notification: .announcement, argument: "\(name) detected!")
        
        Task {
            try? await Task.sleep(for: .seconds(2.5))
            isSuccess = false
            currentMessage = "Try another sign!"
        }
    }
}
